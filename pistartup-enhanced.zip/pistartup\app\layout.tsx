import type React from "react"
import type { Metadata } from "next"
import { GeistMono } from "geist/font/mono"
import { GeistSans } from "geist/font/sans"

import { AppWrapper } from "@/components/app-wrapper"
import "./globals.css"

export const metadata: Metadata = {
  title: "PiStartUP",
  description: "Pi Network startup funding, escrow, and launch management.",
  icons: {
    icon: "/pistartup-logo.jpeg",
    apple: "/pistartup-logo.jpeg",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="antialiased">
        <AppWrapper>{children}</AppWrapper>
      </body>
    </html>
  )
}
