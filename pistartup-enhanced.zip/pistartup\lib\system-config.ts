export const PI_NETWORK_CONFIG = {
  SDK_URL: "https://sdk.minepi.com/pi-sdk.js",
  SDK_LITE_URL: "https://pi-apps.github.io/pi-sdk-lite/build/production/sdklite.js",
  SANDBOX: process.env.NEXT_PUBLIC_PI_SANDBOX === "true",
} as const;

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL?.replace(/\/$/, "") ?? "";

export const BACKEND_URLS = {
  LOGIN: `${API_BASE_URL}/login`,
  LOGIN_PREVIEW: `${API_BASE_URL}/login/preview`,
  STARTUPS: `${API_BASE_URL}/startups`,
  PITCHES: `${API_BASE_URL}/pitches`,
  MILESTONES: `${API_BASE_URL}/milestones`,
  ESCROW_PAYMENTS: `${API_BASE_URL}/payments/escrow`,
  COMMUNITY_VOTES: `${API_BASE_URL}/votes`,
} as const;
