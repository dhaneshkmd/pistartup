"use client"

import Image from "next/image"
import { useMemo, useState } from "react"
import {
  BadgeCheck,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Compass,
  FileText,
  Filter,
  Gauge,
  Landmark,
  LockKeyhole,
  Rocket,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  Vote,
  Wallet,
  type LucideIcon,
} from "lucide-react"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { usePiAuth } from "@/contexts/pi-auth-context"

const PI = "Pi"
const LOGO_SRC = "/pistartup-logo.jpeg"

const navItems = [
  { id: "command", label: "Command", icon: Gauge },
  { id: "market", label: "Market", icon: Compass },
  { id: "builder", label: "Builder", icon: Rocket },
  { id: "escrow", label: "Escrow", icon: LockKeyhole },
  { id: "portfolio", label: "Portfolio", icon: Wallet },
] as const

type ViewId = (typeof navItems)[number]["id"]

const startups = [
  {
    title: "PiRoute Commerce",
    category: "Merchant tooling",
    founder: "Aarav Mehta",
    summary: "Offline-first checkout, QR invoices, and Pi wallet reconciliation for neighborhood sellers.",
    target: 7400,
    raised: 5280,
    backers: 318,
    runway: "8 weeks",
    trust: 92,
  },
  {
    title: "FarmMesh Co-op",
    category: "Supply chain",
    founder: "Lina Okafor",
    summary: "Community produce contracts with milestone escrow and transparent grower payouts in Pi.",
    target: 9600,
    raised: 4080,
    backers: 176,
    runway: "12 weeks",
    trust: 86,
  },
  {
    title: "SkillMint",
    category: "Education",
    founder: "Noor Haddad",
    summary: "Micro-courses where mentors unlock Pi rewards after learners pass verified checkpoints.",
    target: 5200,
    raised: 3910,
    backers: 221,
    runway: "5 weeks",
    trust: 89,
  },
]

const milestones = [
  { name: "KYC verified founder", amount: 300, status: "complete", date: "May 18" },
  { name: "Prototype walkthrough", amount: 850, status: "ready", date: "May 24" },
  { name: "First 25 pilot users", amount: 1250, status: "review", date: "Jun 7" },
  { name: "Mainnet payment audit", amount: 2100, status: "locked", date: "Jun 28" },
]

const readiness = [
  { label: "Pi SDK auth configured", done: true },
  { label: "Founder KYC evidence attached", done: true },
  { label: "Milestone escrow plan drafted", done: true },
  { label: "Community vote window selected", done: false },
  { label: "Mainnet payment memo tested", done: false },
]

const investments = [
  { project: "PiRoute Commerce", invested: 420, value: 512, status: "Milestone 2 live" },
  { project: "SkillMint", invested: 260, value: 296, status: "Vote pending" },
  { project: "FarmMesh Co-op", invested: 180, value: 180, status: "Escrow locked" },
]

export default function PiStartUPApp() {
  const { authMessage, error, hasError, isAuthenticated, reinitialize, userData } = usePiAuth()
  const [activeView, setActiveView] = useState<ViewId>("command")
  const [search, setSearch] = useState("")

  const filteredStartups = useMemo(
    () =>
      startups.filter((startup) =>
        `${startup.title} ${startup.category} ${startup.founder}`
          .toLowerCase()
          .includes(search.toLowerCase()),
      ),
    [search],
  )

  const authState = isAuthenticated ? "Pi verified" : hasError ? "Demo mode" : "Connecting"

  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <BrandMark size="sm" />
              <div>
                <h1 className="text-xl font-semibold">PiStartUP</h1>
                <p className="text-xs text-muted-foreground">Startup funding command center for Pi founders</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Badge variant={isAuthenticated ? "default" : "secondary"} className="h-8 gap-1 px-3">
                <ShieldCheck className="size-3.5" />
                {authState}
              </Badge>
              <Button variant="outline" size="sm" onClick={reinitialize}>
                <Settings2 className="size-4" />
                Sync
              </Button>
              <Avatar className="size-9">
                <AvatarFallback>{userData?.username?.slice(0, 2).toUpperCase() ?? "PI"}</AvatarFallback>
              </Avatar>
            </div>
          </div>

          <nav className="flex gap-1 overflow-x-auto pb-1">
            {navItems.map(({ id, label, icon: Icon }) => (
              <Button
                key={id}
                variant={activeView === id ? "default" : "ghost"}
                size="sm"
                onClick={() => setActiveView(id)}
                className="min-w-fit"
              >
                <Icon className="size-4" />
                {label}
              </Button>
            ))}
          </nav>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[1fr_320px] lg:px-8">
        <section className="space-y-6">
          {activeView === "command" && <CommandView setActiveView={setActiveView} />}
          {activeView === "market" && (
            <MarketView filteredStartups={filteredStartups} search={search} setSearch={setSearch} />
          )}
          {activeView === "builder" && <BuilderView />}
          {activeView === "escrow" && <EscrowView />}
          {activeView === "portfolio" && <PortfolioView />}
        </section>

        <aside className="space-y-4">
          <PiStatusCard
            authMessage={authMessage}
            error={error}
            hasError={hasError}
            isAuthenticated={isAuthenticated}
            username={userData?.username}
          />
          <ReadinessCard />
          <NetworkPulseCard />
        </aside>
      </div>
    </main>
  )
}

function CommandView({ setActiveView }: { setActiveView: (view: ViewId) => void }) {
  const raised = startups.reduce((sum, startup) => sum + startup.raised, 0)
  const target = startups.reduce((sum, startup) => sum + startup.target, 0)
  const backers = startups.reduce((sum, startup) => sum + startup.backers, 0)

  return (
    <div className="space-y-6">
      <section className="rounded-lg border bg-card p-5 shadow-sm">
        <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              <BrandMark size="lg" />
              <Badge variant="outline" className="gap-1">
                <Sparkles className="size-3.5" />
                Founder launch room
              </Badge>
            </div>
            <div className="space-y-2">
              <h2 className="max-w-3xl text-3xl font-semibold">Plan, fund, escrow, and prove startup progress with Pi.</h2>
              <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
                PiStartUP now combines pitch discovery, milestone escrow, community voting, launch readiness, and founder utilities in one focused workspace.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => setActiveView("builder")}>
                <Rocket className="size-4" />
                Build pitch
              </Button>
              <Button variant="outline" onClick={() => setActiveView("market")}>
                <Compass className="size-4" />
                Explore market
              </Button>
            </div>
          </div>

          <div className="rounded-md border bg-background p-4">
            <p className="text-sm font-medium">Funding velocity</p>
            <div className="mt-4 space-y-3">
              <div className="flex items-end justify-between">
                <span className="text-3xl font-semibold">
                  {raised.toLocaleString()} {PI}
                </span>
                <Badge variant="secondary">+18%</Badge>
              </div>
              <Progress value={Math.round((raised / target) * 100)} />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{backers} active backers</span>
                <span>{target.toLocaleString()} {PI} target</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={Wallet} label="Escrow locked" value={`4,500 ${PI}`} detail="3 releases queued" />
        <MetricCard icon={Vote} label="Community votes" value="1,248" detail="86% approval" />
        <MetricCard icon={BadgeCheck} label="KYC-ready teams" value="28" detail="12 added this week" />
        <MetricCard icon={CalendarDays} label="Milestones due" value="7" detail="Next release May 24" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <CardHeader>
            <CardTitle>Priority Startups</CardTitle>
            <CardDescription>Projects with strong trust score and active Pi funding.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {startups.slice(0, 3).map((startup) => (
              <StartupRow key={startup.title} startup={startup} />
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Launch Utility Stack</CardTitle>
            <CardDescription>Operational tools added around the pitch workflow.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { icon: FileText, label: "Pitch memo builder", detail: "Problem, traction, moat, Pi use case" },
              { icon: LockKeyhole, label: "Escrow planner", detail: "Milestone releases with backer visibility" },
              { icon: BarChart3, label: "Funding calculator", detail: "Runway, fee, and target planning" },
              { icon: ShieldCheck, label: "Trust checklist", detail: "KYC, SDK auth, audit, payment memo" },
            ].map(({ icon: Icon, label, detail }) => (
              <div key={label} className="flex gap-3 rounded-md border p-3">
                <div className="flex size-9 items-center justify-center rounded-md bg-secondary">
                  <Icon className="size-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">{label}</p>
                  <p className="text-xs text-muted-foreground">{detail}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function MarketView({
  filteredStartups,
  search,
  setSearch,
}: {
  filteredStartups: typeof startups
  search: string
  setSearch: (value: string) => void
}) {
  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Startup Market</h2>
          <p className="text-sm text-muted-foreground">Discover Pi-native projects by funding, trust score, and category.</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-2.5 size-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search startups"
              className="w-full pl-9 sm:w-64"
            />
          </div>
          <Button variant="outline" size="icon" aria-label="Filter market">
            <Filter className="size-4" />
          </Button>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {filteredStartups.map((startup) => (
          <Card key={startup.title}>
            <CardHeader className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <Badge variant="secondary" className="mb-2">
                    {startup.category}
                  </Badge>
                  <CardTitle>{startup.title}</CardTitle>
                  <CardDescription>by {startup.founder}</CardDescription>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold">{startup.trust}</p>
                  <p className="text-xs text-muted-foreground">trust</p>
                </div>
              </div>
              <p className="text-sm leading-6 text-muted-foreground">{startup.summary}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{startup.raised.toLocaleString()} {PI} raised</span>
                  <span>{startup.target.toLocaleString()} {PI}</span>
                </div>
                <Progress value={Math.round((startup.raised / startup.target) * 100)} />
              </div>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <MiniStat label="Backers" value={startup.backers.toString()} />
                <MiniStat label="Runway" value={startup.runway} />
                <MiniStat label="Funded" value={`${Math.round((startup.raised / startup.target) * 100)}%`} />
              </div>
              <div className="flex gap-2">
                <Button className="flex-1">
                  <Wallet className="size-4" />
                  Back startup
                </Button>
                <Button variant="outline" className="flex-1">
                  <FileText className="size-4" />
                  Review memo
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function BuilderView() {
  const [target, setTarget] = useState(6400)
  const [milestoneCount, setMilestoneCount] = useState(4)
  const releaseSize = Math.round(target / milestoneCount)

  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
      <Card>
        <CardHeader>
          <CardTitle>Pitch Builder</CardTitle>
          <CardDescription>Draft a Pi-native startup pitch with the fields investors need first.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="project">Startup name</Label>
              <Input id="project" placeholder="Example: PiRoute Commerce" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select defaultValue="merchant">
                <SelectTrigger id="category" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="merchant">Merchant tooling</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="supply">Supply chain</SelectItem>
                  <SelectItem value="community">Community services</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="memo">Investor memo</Label>
            <Textarea
              id="memo"
              rows={6}
              placeholder="Problem, Pi utility, proof of demand, revenue model, launch milestones"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="target">Funding target ({PI})</Label>
              <Input
                id="target"
                type="number"
                value={target}
                onChange={(event) => setTarget(Number(event.target.value) || 0)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="milestones">Milestones</Label>
              <Input
                id="milestones"
                type="number"
                min={1}
                max={8}
                value={milestoneCount}
                onChange={(event) => setMilestoneCount(Math.max(1, Number(event.target.value) || 1))}
              />
            </div>
          </div>

          <Button className="w-full">
            <Send className="size-4" />
            Submit for Pi community review
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Funding Calculator</CardTitle>
          <CardDescription>Plan a target that can be released in transparent milestones.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <MiniStat label="Target" value={`${target.toLocaleString()} ${PI}`} />
          <MiniStat label="Release size" value={`${releaseSize.toLocaleString()} ${PI}`} />
          <MiniStat label="Estimated runway" value={`${Math.max(4, milestoneCount * 3)} weeks`} />
          <div className="rounded-md border p-3 text-sm text-muted-foreground">
            Backers see each release before funds move, with status, proof links, and community vote history attached to the milestone.
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function EscrowView() {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-semibold">Milestone Escrow</h2>
        <p className="text-sm text-muted-foreground">Track Pi releases by founder proof, backer vote, and release state.</p>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="divide-y">
            {milestones.map((milestone) => (
              <div key={milestone.name} className="grid gap-3 p-4 sm:grid-cols-[1fr_120px_120px_120px] sm:items-center">
                <div className="flex items-center gap-3">
                  <StatusIcon status={milestone.status} />
                  <div>
                    <p className="font-medium">{milestone.name}</p>
                    <p className="text-xs text-muted-foreground">Release scheduled {milestone.date}</p>
                  </div>
                </div>
                <p className="text-sm font-medium">{milestone.amount.toLocaleString()} {PI}</p>
                <Badge variant={milestone.status === "complete" ? "default" : "secondary"}>{milestone.status}</Badge>
                <Button variant="outline" size="sm">
                  Review
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function PortfolioView() {
  const total = investments.reduce((sum, investment) => sum + investment.value, 0)

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-2xl font-semibold">Backer Portfolio</h2>
          <p className="text-sm text-muted-foreground">A cleaner view of where Pi is committed, locked, and gaining value.</p>
        </div>
        <Badge variant="outline" className="px-3 py-1 text-sm">
          {total.toLocaleString()} {PI} tracked
        </Badge>
      </div>

      <div className="grid gap-4">
        {investments.map((investment) => (
          <Card key={investment.project}>
            <CardContent className="grid gap-3 p-4 sm:grid-cols-[1fr_140px_140px] sm:items-center">
              <div>
                <h3 className="font-semibold">{investment.project}</h3>
                <p className="text-sm text-muted-foreground">{investment.status}</p>
              </div>
              <MiniStat label="Committed" value={`${investment.invested} ${PI}`} />
              <MiniStat label="Current value" value={`${investment.value} ${PI}`} />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function PiStatusCard({
  authMessage,
  error,
  hasError,
  isAuthenticated,
  username,
}: {
  authMessage: string
  error: string | null
  hasError: boolean
  isAuthenticated: boolean
  username?: string
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Landmark className="size-4" />
          Pi Network
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Connection</span>
          <Badge variant={isAuthenticated ? "default" : hasError ? "secondary" : "outline"}>
            {isAuthenticated ? "verified" : hasError ? "demo" : "pending"}
          </Badge>
        </div>
        <p className="text-sm">{isAuthenticated ? `Signed in as @${username ?? "pioneer"}` : error ?? authMessage}</p>
      </CardContent>
    </Card>
  )
}

function ReadinessCard() {
  const complete = readiness.filter((item) => item.done).length

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Launch Readiness</CardTitle>
        <CardDescription>{complete} of {readiness.length} checks complete</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Progress value={(complete / readiness.length) * 100} />
        <div className="space-y-2">
          {readiness.map((item) => (
            <div key={item.label} className="flex items-center gap-2 text-sm">
              {item.done ? (
                <CheckCircle2 className="size-4 text-emerald-600" />
              ) : (
                <Clock3 className="size-4 text-amber-600" />
              )}
              <span className={item.done ? "text-foreground" : "text-muted-foreground"}>{item.label}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

function NetworkPulseCard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Network Pulse</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-3">
        <MiniStat label="Pitches" value="142" />
        <MiniStat label="Votes" value="9.8k" />
        <MiniStat label="Mainnet-ready" value="61%" />
        <MiniStat label="Avg release" value={`720 ${PI}`} />
      </CardContent>
    </Card>
  )
}

function MetricCard({
  detail,
  icon: Icon,
  label,
  value,
}: {
  detail: string
  icon: LucideIcon
  label: string
  value: string
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 p-4">
        <div className="flex size-10 items-center justify-center rounded-md bg-secondary">
          <Icon className="size-5" />
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-lg font-semibold">{value}</p>
          <p className="text-xs text-muted-foreground">{detail}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function StartupRow({ startup }: { startup: (typeof startups)[number] }) {
  return (
    <div className="grid gap-3 rounded-md border p-3 sm:grid-cols-[1fr_160px] sm:items-center">
      <div>
        <div className="flex flex-wrap items-center gap-2">
          <p className="font-medium">{startup.title}</p>
          <Badge variant="outline">{startup.category}</Badge>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">{startup.summary}</p>
      </div>
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span>{startup.raised.toLocaleString()} {PI}</span>
          <span>{startup.trust} trust</span>
        </div>
        <Progress value={Math.round((startup.raised / startup.target) * 100)} />
      </div>
    </div>
  )
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border bg-background p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-semibold">{value}</p>
    </div>
  )
}

function StatusIcon({ status }: { status: string }) {
  if (status === "complete") {
    return <CheckCircle2 className="size-5 text-emerald-600" />
  }

  if (status === "locked") {
    return <LockKeyhole className="size-5 text-muted-foreground" />
  }

  return <Clock3 className="size-5 text-amber-600" />
}

function BrandMark({ size }: { size: "sm" | "lg" }) {
  const imageSize = size === "sm" ? 40 : 80

  return (
    <div
      className={
        size === "sm"
          ? "relative size-10 overflow-hidden rounded-md border bg-white p-1 shadow-sm"
          : "relative size-20 overflow-hidden rounded-lg border bg-white p-1 shadow-sm"
      }
    >
      <Image
        src={LOGO_SRC}
        alt="PiStartUP logo"
        width={imageSize}
        height={imageSize}
        className="h-full w-full object-contain"
        priority={size === "sm"}
      />
    </div>
  )
}
